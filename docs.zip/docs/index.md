---
title: 홈
icon: material/home
---
<!--
<figure markdown="span">
  ![Image title](./images/img_01.png)
</figure>
-->

# :books: 업무관리 사용자교육자료

K-에듀파인 업무관리는 17개 시·도교육청과 산하기관, 1만 2천여 개의 초·중·고등학교 등에 소속된 약 70만여 명의 교직원이 행정업무에 필수적으로 사용하는 시스템입니다.

사용자에게 업무관리에 대한 기능을 효율적으로 안내하고자 온라인 교육자료를 작성하였습니다. :octicons-heart-fill-24:{ .heart }

<figure markdown="span">
  ![Image title](./images/img_01.png)
  <figcaption>K-에듀파인 업무관리 사용자 화면</figcaption>
</figure>

## :material-download: 교육자료 다운로드

내·외부망이 구분된 환경에서는 **내부망에서 온라인 교육자료 사이트 접속이 제한**될 수 있습니다. 이 경우 오프라인으로 활용할 수 있도록 파일을 내려받아 실행하면 됩니다.

!!! Tip "교육자료 오프라인으로 활용 방법"

	<figure markdown="span">
	  ![Image title](./images/img_02.png)
	</figure>

	1. [다운로드 사이트 접속](https://github.com/kedufine/kedufine.github.io "github.com")
	2. **<> Code** 버튼 → **Download ZIP** 클릭
	3. 다운로드 후 **index.html** 실행
	
	  

## :material-chat: AI를 통한 교육자료 활용

!!! Warning "AI 활용 관련 안내사항"

	- 개인이 보유한 AI 서비스 계정을 활용하여 사용자 맞춤형 답변을 생성
	- **AI 답변은 부정확할 수 있으므로** 출력 결과를 반드시 다시 확인
	- 매월 정기배포 시기에 교육자료도 함께 업데이트 예정

### ChatGPT

OpenAI가 개발한 대표적인 대화형 인공지능 서비스로, 자연어 이해와 생성에 강점이 있어 질문 응답, 글쓰기 등에 활용할 수 있습니다.

!!! Tip "ChatGPT를 통한 교육자료 사용방법 안내"

    <figure markdown="span">
	  ![Image title](./images/img_03.png)
	</figure>

	1. [ChatGPT](https://chatgpt.com "chatgpt.com") 접속 후 회원가입 또는 로그인
	2. 좌측 **새 프로젝트** 선택 후 프로젝트 만들기
	3. 오른쪽 상단 메뉴의 **지침 추가**를 선택한 뒤 사용자 맞춤형 지침 추가
	4. **파일 추가** 버튼을 통해 교육자료(`.md` 파일) 추가


### Claude

Anthropic이 개발한 AI 모델로 안전성과 윤리적 사용을 강조하며 긴 문서 처리와 맥락 이해에 강하다고 알려져 있습니다.

??? Tip "Claude를 통한 교육자료 사용방법 안내"

	<figure markdown="span">
	  ![Image title](./images/img_04.png)
	</figure>
	
	1. [Claude](https://claude.ai "claude.ai") 접속 후 회원가입 또는 로그인
	2. 좌측 **프로젝트** 선택 후 프로젝트 만들기
	3. 프로젝트 창에서 **지침**을 선택한 뒤 사용자 맞춤형 지침 추가
	4. **파일**에 교육자료 `.md` 파일 추가

### Gemini

구글 딥마인드가 만든 다중모달 AI로, 텍스트뿐 아니라 이미지, 코드 등 다양한 입력을 처리하며 특히 구글 생태계(Gmail, Docs 등)와의 통합성이 강점입니다.

??? Tip "Gemini를 통한 교육자료 사용방법 안내"

	<figure markdown="span">
	  ![Image title](./images/img_05.png)
	</figure>
	
	1. [Gemini](https://gemini.google.com "gemini.google.com") 접속 후 회원가입 또는 로그인
	2. 좌측 **Gems 탐색하기** 선택 후 **새 Gem** 선택
	3. Gem의 이름, 요청사항(지침), 지식(교육자료 `.md` 파일) 추가

### NotebookLM

구글이 제공하는 개인화된 AI 연구 도구로 사용자가 올린 자료를 기반으로 분석·정리·요약을 수행할 수 있어 특히 학습에 특화된 서비스입니다.

!!! Tip "NotebookLM을 통한 교육자료 사용방법 안내"

	<figure markdown="span">
	  ![Image title](./images/img_06.png)
	</figure>
	
	1. [NotebookLM](https://notebooklm.google.com "notebooklm.google.com") 접속 후 로그인
	2. **새 노트 만들기** 선택 후 소스(교육자료 `.md` 파일) 추가


## :material-copyright: 저작권

© 2025 한국교육학술정보원(KERIS). 본 교육자료의 저작권은 한국교육학술정보원에 있으며, 무단 복제·배포를 금합니다.

© 2025 KERIS(Korea Education and Research Information Service). All rights reserved. Unauthorized reproduction or distribution is prohibited.










